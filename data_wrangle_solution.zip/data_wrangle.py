"""This is a Python script that formats csv file column names
@author Jarod Beardsley
@version 7/16/2021
"""
import argparse
import parsons
import re


def main(files):
    """Read in csv arg files, reformat, merge, and return final table."""
    from parsons import Table
    table = reformat(Table.from_csv(files.get("a")))
    table.concat(reformat(Table.from_csv(files.get("b"))))
    return table


def parse_arguments():
    """Read arguments from command line."""
    parser = argparse.ArgumentParser(description='Process some csv files.')
    parser.add_argument('-a', metavar='csv1', required=True, type=str, default="",
                        help='the first csv file to join, reformat, and return')
    parser.add_argument('-b', metavar='csv2', required=True, type=str, default="",
                        help='the second csv file to join, reformat, and return')

    return vars(parser.parse_args())


def reformat(table):
    """Remove duplicates in column names, send to lower-case, remove white space and the following chars: ?,!.&$%"""
    column_list = []
    regex = re.compile('[? ,!.&$%]')
    for column in table.columns:
        try:
            if column in column_list:
                table.rename_column(column, column + str(column_list.count(column)))
            column_list.append(column)
            table.rename_column(column, regex.sub('', column.lower()))

        except ValueError as e:
            pass
    return table


if __name__ == '__main__':
    main(parse_arguments()).to_csv("wrangled_output.csv")

