###Merge CSVs

This is a python script that accepts two csv files as input and returns a single, merged csv with column names
normalized to exclude whitespace, uppercase, duplicates, and the following chars: [ ? ,  ! . & $ % ] using Parsons.

The approach: I tried to keep things simple, clean, and modular. I went with the argparse library to parse the
parameters because it was the first thing that came up when I googled it (though I swear there's a simpler way I've
seen before that's slipping my mind, ah well). In the end, the files simply go from csv to table and back again.
I didn't use the column normalization method built into Parsons because it only allows alphanumeric characters, which
wouldn't have been accurate to the list of disallowed characters in the instructions. One particularly quirky thing was
the name of the output csv. I couldn't think of a way to dynamically generate a good name for the merged output table,
so I kept it simple and hard-coded a generic name. Not ideal, but for now let whoever is running the script figure out
a name.

NOTE: This script only accepts two input files. In the future, it shouldn't be very much trouble to change.

##Usage:
#command line
python merge_csv.py -a file1.csv -b file2.csv

#Pycharm run configuration
-a file1.csv -b file2.csv

##Bugs
Currently, I can't guarantee that duplicate columns will get renamed. I've implemented logic that should
rename duplicate columns with an identifying number based on how many duplicates have
been parsed before it, but it's difficult to tell if it works. It would be possible to remove duplicate columns, using
the remove_column() method, but this is not an very good solution as it could result in data loss. I started getting a
new error during testing while adding duplicate fields to the input CSV's. It reads "petl.errors.FieldSelectionError:
selection is not a field or valid field index: 'committeeID'"

It seems the inputtypename column is not being populated properly in the output table. This is a serious bug as data
is being lost and should be fixed before the script is used in production.

It bothers my sense of thoroughness but the instructions say not to take too much time on this challenge, so I won't
and am turning it in as-is.




